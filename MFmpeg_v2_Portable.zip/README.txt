MFmpeg v2 - Portable Edition
============================

Image sequence to video converter for Windows.

QUICK START
-----------
1. Place ffmpeg.exe in this folder (if not already included)
   Download from: https://www.gyan.dev/ffmpeg/builds/
   Get the "essentials" build and extract ffmpeg.exe here.

2. Run install_context_menu.bat to add right-click integration.
   Then right-click any image file and select "Open sequence in MFmpeg".

3. Or just run MFmpegV2.exe directly and use Browse to select files.

UNINSTALL
---------
Run uninstall_context_menu.bat to remove the right-click menu entries.
Delete this folder to remove the application.

KEYBOARD SHORTCUTS
-------------------
I           Set in-point
O           Set out-point
Left/Right  Step one frame
Home/End    Jump to first/last frame

Settings are saved to: %APPDATA%\MFmpeg\v2_settings.ini

https://friskcinema.com
